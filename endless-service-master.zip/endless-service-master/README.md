# Endless Service

This is just a project showing how to run an Android Foreground Service that will never stop running.
