package com.robertohuertas.endless

import android.util.Log

fun log(msg: String) {
    Log.d("ENDLESS-SERVICE", msg)
}
