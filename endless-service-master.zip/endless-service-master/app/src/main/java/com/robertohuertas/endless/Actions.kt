package com.robertohuertas.endless

enum class Actions {
    START,
    STOP
}
